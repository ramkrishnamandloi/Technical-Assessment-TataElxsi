package com.example.customer.Technical.Assessment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechnicalAssessmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechnicalAssessmentApplication.class, args);
	}

}
