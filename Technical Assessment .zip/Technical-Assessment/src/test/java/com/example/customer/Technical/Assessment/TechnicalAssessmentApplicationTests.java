package com.example.customer.Technical.Assessment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechnicalAssessmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
